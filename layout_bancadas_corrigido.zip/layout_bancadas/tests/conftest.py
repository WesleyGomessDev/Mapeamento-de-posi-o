import os,sys,tempfile,pytest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
@pytest.fixture
def client(tmp_path,monkeypatch):
 monkeypatch.setenv('LAYOUT_DB',str(tmp_path/'test.db'))
 import importlib,app as module
 importlib.reload(module)
 module.app.config.update(TESTING=True)
 return module.app.test_client()
