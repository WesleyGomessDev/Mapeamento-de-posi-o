def sample():return {'label':'1002','desk':'A01','side':'frente','floor':'3º andar','x':25.5,'y':20.2,'monitors':2,'status':'ocupada','kind':'fixa'}
def test_health(client):assert client.get('/api/health').status_code==200
def test_crud_without_delete(client):
 r=client.post('/api/positions',json=sample());assert r.status_code==201;p=r.get_json()['position']
 r=client.put('/api/positions/'+p['id'],json={'user_name':'Ana','version':p['version']});assert r.status_code==200;assert r.get_json()['position']['user_name']=='Ana'
 assert client.delete('/api/positions/'+p['id']).status_code==405
def test_version_conflict(client):
 p=client.post('/api/positions',json=sample()).get_json()['position'];client.put('/api/positions/'+p['id'],json={'x':30,'version':p['version']});assert client.put('/api/positions/'+p['id'],json={'x':31,'version':p['version']}).status_code==409
def test_undo_redo(client):
 client.post('/api/positions',json=sample());assert len(client.get('/api/positions').get_json()['positions'])==1
 assert client.post('/api/undo').status_code==200;assert len(client.get('/api/positions').get_json()['positions'])==0
 assert client.post('/api/redo').status_code==200;assert len(client.get('/api/positions').get_json()['positions'])==1
