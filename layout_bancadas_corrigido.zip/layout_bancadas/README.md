# Layout de Bancadas

Aplicação local Flask + SQLite para mapear posições sobre uma planta responsiva.

## Recursos
- Seleção, inclusão, edição e movimentação sem exclusão
- Coordenadas percentuais
- Filtros e indicadores
- SQLite WAL, revisão incremental e bloqueio otimista
- Desfazer/refazer por snapshots
- Importação Excel e JSON, exportação Excel/JSON
- Sincronização entre abas por polling
- Backup automático antes de importações
- Múltiplos andares e troca da planta por upload

## Executar no CachyOS/Linux
```bash
chmod +x iniciar.sh
./iniciar.sh
```
Para Fish manualmente:
```fish
python -m venv .venv
source .venv/bin/activate.fish
pip install -r requirements.txt
python app.py
```

## Windows
Execute `iniciar.bat`.

Abra http://127.0.0.1:5000

## Testes
```bash
pytest -q
```
