from __future__ import annotations
import io, json, os, shutil, sqlite3, uuid, unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, jsonify, render_template, request, send_file
from openpyxl import Workbook, load_workbook
from werkzeug.utils import secure_filename

BASE_DIR=Path(__file__).resolve().parent
DATA_DIR=BASE_DIR/'data'; DB_PATH=Path(os.getenv('LAYOUT_DB', DATA_DIR/'layout.db'))
IMAGE_DIR=BASE_DIR/'static'/'images'; BACKUP_DIR=DATA_DIR/'backups'
for p in (DATA_DIR,IMAGE_DIR,BACKUP_DIR): p.mkdir(parents=True,exist_ok=True)
app=Flask(__name__); app.config['MAX_CONTENT_LENGTH']=12*1024*1024
STATUS_META={
 'livre':{'label':'Livre','color':'#3AA03F','icon':'○','pattern':'solid','aliases':['livre']},
 'ocupada':{'label':'Ocupada','color':'#2B5BA9','icon':'●','pattern':'solid','aliases':['ocupada','ativa','ativo']},
 'manutencao':{'label':'Em manutenção','color':'#E4B862','icon':'◆','pattern':'striped','aliases':['manutencao','manutenção','em manutencao','em manutenção']},
 'indisponivel':{'label':'Indisponível','color':'#D73C3D','icon':'×','pattern':'cross','aliases':['indisponivel','indisponível','inativa','inativo']}}
FIELDS=['label','desk','side','source_position','floor','user_name','racf','hostname','asset_tag','model','ip','area','x','y','monitors','status','kind','notes']
TEXT_FIELDS=['label','desk','side','source_position','floor','user_name','racf','hostname','asset_tag','model','ip','area','status','kind','notes']

def now(): return datetime.now(timezone.utc).isoformat()
def normalize(s): return ''.join(c for c in unicodedata.normalize('NFD',str(s or '').strip().lower()) if unicodedata.category(c)!='Mn')
@contextmanager
def db():
 c=sqlite3.connect(DB_PATH,timeout=15); c.row_factory=sqlite3.Row
 c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA busy_timeout=15000'); c.execute('PRAGMA journal_mode=WAL')
 try:
  yield c; c.commit()
 except Exception:
  c.rollback(); raise
 finally:c.close()

def init_db():
 with db() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS positions(id TEXT PRIMARY KEY,label TEXT NOT NULL,desk TEXT,side TEXT,source_position TEXT,floor TEXT,user_name TEXT,racf TEXT,hostname TEXT,asset_tag TEXT,model TEXT,ip TEXT,area TEXT,x REAL NOT NULL,y REAL NOT NULL,monitors INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'livre',kind TEXT NOT NULL DEFAULT 'fixa',notes TEXT DEFAULT '',version INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL,CHECK(side IN ('frente','fundo') OR side IS NULL OR side=''),CHECK(x>=0 AND x<=100),CHECK(y>=0 AND y<=100),CHECK(monitors>=0));
  CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,action TEXT NOT NULL,position_id TEXT,before_snapshot TEXT NOT NULL,after_snapshot TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS redo_history(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,action TEXT NOT NULL,position_id TEXT,before_snapshot TEXT NOT NULL,after_snapshot TEXT NOT NULL);
  CREATE INDEX IF NOT EXISTS idx_positions_status ON positions(status); CREATE INDEX IF NOT EXISTS idx_positions_desk ON positions(desk); CREATE INDEX IF NOT EXISTS idx_positions_hostname ON positions(hostname); CREATE INDEX IF NOT EXISTS idx_positions_asset_tag ON positions(asset_tag); CREATE INDEX IF NOT EXISTS idx_positions_floor ON positions(floor); CREATE UNIQUE INDEX IF NOT EXISTS ux_positions_floor_label ON positions(floor,label); CREATE UNIQUE INDEX IF NOT EXISTS ux_positions_floor_desk_side ON positions(floor,desk,side) WHERE desk IS NOT NULL AND desk!='' AND side IS NOT NULL AND side!='';''')
  c.execute("INSERT OR IGNORE INTO settings VALUES('revision','0')"); c.execute("INSERT OR IGNORE INTO settings VALUES('schema_version','3')"); c.execute("INSERT OR IGNORE INTO settings VALUES('image','planta_3_andar.png')")

def rows(c): return [dict(r) for r in c.execute('SELECT * FROM positions ORDER BY label COLLATE NOCASE')]
def snapshot(c): return json.dumps(rows(c),ensure_ascii=False,separators=(',',':'))
def revision(c): return int(c.execute("SELECT value FROM settings WHERE key='revision'").fetchone()[0])
def bump(c):
 r=revision(c)+1;c.execute("UPDATE settings SET value=? WHERE key='revision'",(str(r),));return r
def record(c,action,pid,before,after):
 c.execute('INSERT INTO history(created_at,action,position_id,before_snapshot,after_snapshot) VALUES(?,?,?,?,?)',(now(),action,pid,before,after)); c.execute('DELETE FROM redo_history')
def restore(c,data):
 items=json.loads(data); c.execute('DELETE FROM positions')
 for p in items:
  cols=list(p); c.execute(f"INSERT INTO positions({','.join(cols)}) VALUES({','.join('?'*len(cols))})",[p[k] for k in cols])
def backup():
 if DB_PATH.exists(): shutil.copy2(DB_PATH,BACKUP_DIR/f"layout_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
def status_key(v):
 n=normalize(v)
 for k,m in STATUS_META.items():
  if n in [normalize(x) for x in m['aliases']]: return k
 raise ValueError(f'Status desconhecido "{v}".')
def coord(v,name):
 try:n=float(v)
 except: raise ValueError(f'{name} deve ser numérico.')
 if not 0<=n<=100: raise ValueError(f'{name} deve estar entre 0 e 100.')
 return round(n,2)
def monitor(v):
 try:
  if str(v).strip().endswith('.0'): v=float(v)
  n=int(v)
 except: raise ValueError('Monitores deve ser um número inteiro.')
 if n<0:raise ValueError('Monitores deve ser maior ou igual a zero.')
 return n
def clean(payload,partial=False):
 out={}
 for k in FIELDS:
  if k in payload: out[k]=payload[k]
 if not partial or 'label' in out:
  out['label']=str(out.get('label','')).strip()
  if not out['label']:raise ValueError('Informe o Número da posição.')
 for k in TEXT_FIELDS:
  if k in out and k not in ('label','status'):out[k]=str(out[k] or '').strip()
 if 'side' in out:
  out['side']=normalize(out['side'])
  if out['side'] not in ('','frente','fundo'):raise ValueError('Lado deve ser frente ou fundo.')
 if 'x' in out:out['x']=coord(out['x'],'X')
 elif not partial:raise ValueError('Informe X.')
 if 'y' in out:out['y']=coord(out['y'],'Y')
 elif not partial:raise ValueError('Informe Y.')
 if 'monitors' in out:out['monitors']=monitor(out['monitors'])
 elif not partial:out['monitors']=0
 if 'status' in out: out['status']=status_key(out['status'])
 elif not partial:out['status']='livre'
 if 'kind' in out:
  out['kind']=normalize(out['kind'])
  if out['kind'] not in ('fixa','rotativa'):raise ValueError('Tipo deve ser fixa ou rotativa.')
 elif not partial:out['kind']='fixa'
 return out

@app.get('/')
def index():return render_template('index.html')
@app.get('/api/meta')
def meta():
 with db() as c:
  image=c.execute("SELECT value FROM settings WHERE key='image'").fetchone()[0]
 return jsonify(statuses=[{'key':k,**{x:v[x] for x in ['label','color','icon','pattern']}} for k,v in STATUS_META.items()],glossary={'bancada':'Grupo identificado pelas letras A a F','mesa':'Módulo físico, como A01','posicao':'Cada lado individual da mesa'},image=image)
@app.get('/api/positions')
def get_positions():
 with db() as c:
  r=revision(c); since=request.args.get('since',type=int)
  if since is not None and since==r:return jsonify(changed=False,revision=r)
  return jsonify(changed=True,revision=r,positions=rows(c))
@app.post('/api/positions')
def create_position():
 p=clean(request.get_json(force=True) or {}); pid=str(uuid.uuid4())
 with db() as c:
  b=snapshot(c); cols=['id']+list(p)+['version','updated_at']; vals=[pid]+list(p.values())+[1,now()]
  c.execute(f"INSERT INTO positions({','.join(cols)}) VALUES({','.join('?'*len(cols))})",vals); a=snapshot(c);record(c,'create',pid,b,a);r=bump(c)
  pos=dict(c.execute('SELECT * FROM positions WHERE id=?',(pid,)).fetchone())
 return jsonify(position=pos,revision=r),201
@app.put('/api/positions/<pid>')
def update_position(pid):
 body=request.get_json(force=True) or {}; expected=body.pop('version',None); p=clean(body,partial=True)
 if not p:return jsonify(error='Nenhum campo válido foi informado.'),400
 with db() as c:
  old=c.execute('SELECT * FROM positions WHERE id=?',(pid,)).fetchone()
  if not old:return jsonify(error='Posição não encontrada.'),404
  if expected is None or int(expected)!=old['version']:return jsonify(error='A posição foi alterada em outra aba. Recarregue os dados.',code='version_conflict',current=dict(old)),409
  b=snapshot(c); p['version']=old['version']+1;p['updated_at']=now(); sets=','.join(f'{k}=?' for k in p);c.execute(f'UPDATE positions SET {sets} WHERE id=?',list(p.values())+[pid]);a=snapshot(c);record(c,'update',pid,b,a);r=bump(c);pos=dict(c.execute('SELECT * FROM positions WHERE id=?',(pid,)).fetchone())
 return jsonify(position=pos,revision=r)
@app.post('/api/undo')
def undo():
 with db() as c:
  op=c.execute('SELECT * FROM history ORDER BY id DESC LIMIT 1').fetchone()
  if not op:return jsonify(error='Sem alterações para desfazer.'),400
  restore(c,op['before_snapshot']);c.execute('INSERT INTO redo_history(created_at,action,position_id,before_snapshot,after_snapshot) VALUES(?,?,?,?,?)',(op['created_at'],op['action'],op['position_id'],op['before_snapshot'],op['after_snapshot']));c.execute('DELETE FROM history WHERE id=?',(op['id'],));r=bump(c)
 return jsonify(ok=True,revision=r)
@app.post('/api/redo')
def redo():
 with db() as c:
  op=c.execute('SELECT * FROM redo_history ORDER BY id DESC LIMIT 1').fetchone()
  if not op:return jsonify(error='Sem alterações para refazer.'),400
  restore(c,op['after_snapshot']);c.execute('INSERT INTO history(created_at,action,position_id,before_snapshot,after_snapshot) VALUES(?,?,?,?,?)',(op['created_at'],op['action'],op['position_id'],op['before_snapshot'],op['after_snapshot']));c.execute('DELETE FROM redo_history WHERE id=?',(op['id'],));r=bump(c)
 return jsonify(ok=True,revision=r)

def import_records(records,action):
 valid=[]; errors=[]; labels=set(); desk_sides=set()
 for i,raw in enumerate(records,start=2):
  try:
   p=clean(raw); label_key=(p.get('floor',''),p['label']); key=(p.get('floor',''),p.get('desk',''),p.get('side',''))
   if label_key in labels:raise ValueError(f'Posição duplicada no andar: {p["floor"]} / {p["label"]}.')
   if all(key) and key in desk_sides:raise ValueError(f'Mesa/Lado duplicado: {key[0]} / {key[1]} {key[2]}.')
   labels.add(label_key);desk_sides.add(key);valid.append(p)
  except ValueError as e:errors.append(f'Linha {i}: {e}')
 if errors: return None,errors
 backup()
 with db() as c:
  b=snapshot(c);c.execute('DELETE FROM positions')
  for p in valid:
   pid=str(uuid.uuid4());cols=['id']+list(p)+['version','updated_at'];vals=[pid]+list(p.values())+[1,now()];c.execute(f"INSERT INTO positions({','.join(cols)}) VALUES({','.join('?'*len(cols))})",vals)
  a=snapshot(c);record(c,action,None,b,a);r=bump(c)
 return r,[]
@app.post('/api/import-excel')
def import_excel():
 f=request.files.get('file')
 if not f:return jsonify(error='Selecione um arquivo Excel.'),400
 try:
  ws=load_workbook(f,read_only=True,data_only=True).active; allrows=list(ws.iter_rows(values_only=True)); headers=[normalize(x).replace(' ','_') for x in allrows[0]]
  aliases={'andar':'floor','posicao':'label','posição':'label','mesa':'desk','lado':'side','usuario':'user_name','usuário':'user_name','inventario':'asset_tag','inventário':'asset_tag','modelo':'model','area':'area','área':'area','monitores':'monitors','status':'status','tipo':'kind','observacao':'notes','observação':'notes','x':'x','y':'y','racf':'racf','hostname':'hostname','ip':'ip'}
  records=[]
  floor_counts={}
  for idx,row in enumerate(allrows[1:]):
   d={aliases.get(h,h):(v if v is not None else '') for h,v in zip(headers,row)}
   floor=str(d.get('floor','')).strip(); local=floor_counts.get(floor,0); floor_counts[floor]=local+1
   if not d.get('x'): d['x']=10+(local%8)*11
   if not d.get('y'): d['y']=15+((local//8)%6)*13
   records.append(d)
  r,errors=import_records(records,'import_excel')
  if errors:return jsonify(error='Importação cancelada.',details=errors),400
  return jsonify(ok=True,imported=len(records),revision=r)
 except Exception as e:return jsonify(error=f'Falha ao ler Excel: {e}'),400
@app.post('/api/import-json')
def import_json():
 f=request.files.get('file')
 if not f:return jsonify(error='Selecione um arquivo JSON.'),400
 try:data=json.load(f);records=data.get('positions',[]);r,errors=import_records(records,'import_json')
 except Exception as e:return jsonify(error=f'JSON inválido: {e}'),400
 if errors:return jsonify(error='Importação cancelada.',details=errors),400
 return jsonify(ok=True,imported=len(records),revision=r)
@app.get('/api/export-json')
def export_json():
 with db() as c:
  image=c.execute("SELECT value FROM settings WHERE key='image'").fetchone()[0];data={'schema_version':3,'image':image,'positions':rows(c)}
 buf=io.BytesIO(json.dumps(data,ensure_ascii=False,indent=2).encode());buf.seek(0);return send_file(buf,as_attachment=True,download_name='layout_bancadas.json',mimetype='application/json')
@app.get('/api/export-excel')
def export_excel():
 with db() as c: ps=rows(c)
 wb=Workbook();ws=wb.active;ws.title='Posições';headers=['Andar','Posição','Mesa','Lado','Usuário','RACF','Hostname','Inventário','Modelo','IP','Área','Monitores','Status','Tipo','Observação','X','Y'];ws.append(headers)
 keys=['floor','label','desk','side','user_name','racf','hostname','asset_tag','model','ip','area','monitors','status','kind','notes','x','y']
 for p in ps:ws.append([p.get(k,'') for k in keys])
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for col in ws.columns:ws.column_dimensions[col[0].column_letter].width=min(30,max(12,max(len(str(c.value or '')) for c in col)+2))
 buf=io.BytesIO();wb.save(buf);buf.seek(0);return send_file(buf,as_attachment=True,download_name='layout_bancadas.xlsx',mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
@app.post('/api/upload-image')
def upload_image():
 f=request.files.get('file')
 if not f or Path(f.filename).suffix.lower() not in ('.png','.jpg','.jpeg','.webp'):return jsonify(error='Envie PNG, JPG, JPEG ou WEBP.'),400
 name='planta_'+uuid.uuid4().hex[:10]+Path(secure_filename(f.filename)).suffix.lower();f.save(IMAGE_DIR/name)
 with db() as c:c.execute("UPDATE settings SET value=? WHERE key='image'",(name,));r=bump(c)
 return jsonify(ok=True,image=name,revision=r)
@app.get('/api/health')
def health():
 with db() as c:return jsonify(status='ok',database=str(DB_PATH),revision=revision(c),positions=c.execute('SELECT COUNT(*) FROM positions').fetchone()[0])
@app.errorhandler(sqlite3.IntegrityError)
def integrity(e):return jsonify(error='Conflito de dados: número da posição ou combinação Mesa/Lado já existe.',details=str(e)),409
@app.errorhandler(sqlite3.OperationalError)
def operational(e):
 text=str(e).lower();return (jsonify(error='O banco está em uso. Feche programas que abriram data/layout.db e tente novamente.'),503) if ('locked' in text or 'busy' in text) else (jsonify(error='Falha ao acessar o banco de dados.'),500)
@app.errorhandler(ValueError)
def value(e):return jsonify(error=str(e)),400
init_db()
if __name__=='__main__':app.run(host='127.0.0.1',port=5000,debug=False)
